package com.idt.installation;

import android.content.Context;
import android.graphics.*;
import android.view.*;

public class SignatureView extends View {
    private final Paint paint = new Paint();
    private final Path path = new Path();
    private Bitmap bitmap;
    public SignatureView(Context context, android.util.AttributeSet attrs) {
        super(context, attrs);
        paint.setColor(Color.BLACK); paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5f); paint.setStrokeCap(Paint.Cap.ROUND);
        setBackgroundColor(Color.WHITE);
    }
    protected void onDraw(Canvas canvas) { super.onDraw(canvas); canvas.drawPath(path, paint); }
    public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(), y=e.getY();
        if(e.getAction()==MotionEvent.ACTION_DOWN){path.moveTo(x,y);invalidate();return true;}
        if(e.getAction()==MotionEvent.ACTION_MOVE){path.lineTo(x,y);invalidate();return true;}
        return true;
    }
    public void clear(){path.reset();invalidate();}
    public Bitmap getBitmap(){
        Bitmap b=Bitmap.createBitmap(getWidth(),getHeight(),Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(b); c.drawColor(Color.WHITE); c.drawPath(path,paint); return b;
    }
}

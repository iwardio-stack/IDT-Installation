# IDT Installation Sign-Off Android App

Updated features:
- Black industrial interface with official IDT logo
- Company details: Unit 7, Concert Park, Joe Mark's Boulevard, Retreat
- Phone: 0645558411
- Email: iwardio@idtsteelwork.co.za
- Ten installation item lines
- Multiple site photos
- Photos included on separate PDF pages
- Client and installer signatures
- PDF sharing via WhatsApp/email

Build on GitHub:
1. Upload the entire project contents to the repository root.
2. Ensure `.github/workflows/build-apk.yml` is included.
3. Open Actions and run Build IDT APK.
4. Download the successful IDT-Installation-APK artifact.
